<!--
    Escribe un script de PHP que muestre en pantalla tu nombre completo, dirección y número de teléfono. Cada dato deberá aparecer en una línea diferente.
-->
<?php
echo "Roberto Sánchez Martín <br> Calle Rubinstein Nº27 <br> 648180512";
?>