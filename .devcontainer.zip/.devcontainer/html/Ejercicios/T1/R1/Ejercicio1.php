<!--
    Investiga en la documentación el uso de la función phpInfo y muestra únicamente por pantalla información de configuración y del entorno.
-->
<?php
echo "<pre>";
phpinfo(20);
echo "</pre>";
?>