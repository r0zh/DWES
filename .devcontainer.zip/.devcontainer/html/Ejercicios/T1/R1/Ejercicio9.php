<!--
    Crea un array que permita almacenar el nombre, apellidos, edad, dirección y
    teléfono de una persona. Utiliza índices de tipo asociativo para identificar cada
    uno de Los valores.
-->
<?php
$usuario = ["nombre" => "Juan", "apellidos" => "Perez", "edad" => "23", "direccion" => "Calle 1", "telefono" => "1234567"];
echo $usuario["nombre"];
?>