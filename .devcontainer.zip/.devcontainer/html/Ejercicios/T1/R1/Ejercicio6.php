<!--
    Mediante un script de PHP, y utilizando únicamente las funciones de salida
    básica, dibuja en pantalla una pirámide hueca utilizando asteriscos. El ancho de
    la figura tendrá como máximo 9 asteriscos.
            *
           * *
          *   *
         * * * *
-->
<?php
echo "&nbsp&nbsp&nbsp&nbsp*<br>";
echo "&nbsp&nbsp*&nbsp&nbsp*<br>";
echo "&nbsp*&nbsp&nbsp&nbsp&nbsp*<br>";
echo "*&nbsp*&nbsp*&nbsp*<br>";
?>