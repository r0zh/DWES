<!--
    Escribe un programa que utilice las variables $x y $y. Asignales los valores 144
    y 999 respectivamente. A continuacion, muestra por pantalla el valor de cada
    variable, la suma, la resta, la división y la multiplicacién en lineas sucesivas.
-->
<?php
$x = 144;
$y = 999;
echo "El valor de x es: $x <br>";
echo "El valor de y es: $y <br>";
echo "La suma de x e y es: " . ($x + $y) . "<br>";
echo "La resta de x e y es: " . ($x - $y) . "<br>";
echo "La división de x e y es: " . ($x / $y) . "<br>";
echo "La multiplicación de x e y es: " . ($x * $y) . "<br>";
?>