<!--
    Dibuja el siguiente array. Hazlo sin hacer uso del intérprete.
    $datos = [ 77, 82, 54, 18, 2 => “Los Fratelli” ]
-->
<?php
$datos = [77, 82, 54, 18, 2 => "Los Fratelli"];

/*
$datos[0] = 77;
$datos[1] = 82;
$datos[2] = "Los Fratelli";
$datos[3] = 18;
*/
?>