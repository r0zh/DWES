<!--
    Utiliza PHP para mostrar por pantalla el mensaje «La simplicidad llevada al
    extremo se convierte en elegancia». Añade bajo el mensaje, entre paréntesis y
    en cursiva el nombre del autor de la cita: Jon Franklin.
-->
<?php
echo "La simplicidad llevada al extremo se convierte en elegancia <br> <i>(Jon Franklin)</i>";
?>