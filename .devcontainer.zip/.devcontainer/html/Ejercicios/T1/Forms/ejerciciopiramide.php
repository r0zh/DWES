<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piramide</title>
</head>

<body>
    <form id="" action="./scripts/procesapiramide.php" method="post">
        <label for="nombre">Introduce el numero:</label>
        <input type="number" id="numero" name="numero">
        <br>
        <button value="enviar" type="submit">Enviar</button>
    </form>
</body>

</html>