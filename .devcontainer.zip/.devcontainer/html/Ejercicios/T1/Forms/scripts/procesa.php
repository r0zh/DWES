<h1>!!HOLAAA
    <?= "{$_POST["nombre"]} {$_POST["apellido"]}" ?>!!
</h1>

<?php
echo "<pre>" . print_r($_GET, true) . "</pre>";
?>