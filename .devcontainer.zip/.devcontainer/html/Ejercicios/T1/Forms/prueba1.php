<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <form id="" action="./scripts/procesa.php" method="post">
        <label for="nombre">Introduce tu nombre:</label>
        <input type="text" id="nombre" name="nombre">
        <br>
        <label for="apellido">Introduce tu apellido:</label>
        <input type="text" id="apellido" name="apellido">
        <br>
        <button value="enviar" type="submit">Enviar</button>
    </form>
</body>

</html>